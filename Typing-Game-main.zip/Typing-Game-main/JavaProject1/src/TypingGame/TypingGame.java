package TypingGame;

import javax.swing.*;

// Oyunun ana sınıfı burada
public class TypingGame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Oyunun penceresini oluşturuyor
            JFrame frame = new JFrame("Typing Game");
            GamePanel panel = new GamePanel();

            // Java Swing kullanarak ana pencere ayarları
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Uygulama kapanışında kaynakları temizler
            frame.setSize(1000, 800); // Pencere boyutlarını ayarlama
            frame.setResizable(false); // Pencerenin yeniden boyutlandırılmasını engeller
            frame.add(panel); // Oyun panelini pencereye ekler
            frame.setVisible(true); // Pencerenin görünür olmasını sağlar

            // Oyun panelini başlatır
            panel.start();
        });
    }
}