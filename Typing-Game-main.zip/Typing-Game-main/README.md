# Typing-Game
You must type falling words before they can fall down

It was started with the goal of typing the words falling from above before they reach the bottom.
A black screen and an array were created.
I can add more things if requested.

Eklenebilecekler: 
1. Rendering Names
   Replace the String[] names array with an ArrayList<Word> to store Word objects dynamically.
2. Falling Mechanic
   Introduce a run() method in the GamePanel class
3. Input Handling
   Implement the KeyListener interface in the GamePanel class.
4. Game Over Logic
   Check the y position of each word. If it exceeds the panel height, set a gameOver flag to true.
5. Scoring System
   Add an integer variable score to the GamePanel class.
6. Word Spawning
   Randomly select a word from the names array.

